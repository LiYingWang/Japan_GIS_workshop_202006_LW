This package is Global Map version 1 (national & regional) in user friendly format.
Data were produced by National Mapping Organization of respective countries and regions under their responsibilities and derived into other format by the Geospatial Information Authority of Japan.
Metadata can be downloaded with the data in official format.

National Mapping Organization of respective countries and regions have the copyright of the data.
Please read the following the sentence about use of this data and follow the instruction.

Japan: Global Map Japan is subject to copyright law of Japan and copyright protection by an international treaty. 
	The data is available at no charge, regardless of the non-profit objectives and commercial use, 
	under the "Geospatial Information Authority of Japan Website Terms of Use", http://www.gsi.go.jp/ENGLISH/page_e30286.html.
	You need cite the source when using this data and comply the other terms of use described in the document. 
	For any enquiries, please contact Geospatial Information Authoriry of Japan (chikyuchizu@gsi.go.jp).
